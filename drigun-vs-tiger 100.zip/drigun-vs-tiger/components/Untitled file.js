---

## 📄 2. `INSTALLATION.md`

```markdown
# Installation Guide – Dragon vs Tiger Game

Follow these steps to set up the project on your system.

---

### Requirements
- Node.js (LTS version recommended)
- Expo CLI
- Expo Go (on your phone)
- Git (optional)

---

### Steps
1. Unzip the project folder.
2. Open terminal in the project folder.
3. Run:
   ```sh
      npm install