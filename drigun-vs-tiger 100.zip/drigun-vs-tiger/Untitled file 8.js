---

## 📄 3. `LICENSE.txt`

```text
Copyright © 2025 Mustafa

This project "Dragon vs Tiger – Coin Betting Game" is sold as a codebase package.  

You may:
- Use it for personal or commercial projects.
- Modify or extend the code as needed.

You may NOT:
- Resell this code to another buyer without permission.
- Claim ownership of the original source.

Contact: mustafa644 (GitHub/Expo)