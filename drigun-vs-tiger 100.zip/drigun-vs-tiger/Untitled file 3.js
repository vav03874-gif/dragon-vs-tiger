// payfast payload
{
  merchant_id: "xxxxx",
    merchant_key: "yyyyy",
      amount: "100.00",
        item_name: "100 Coins",
          return_url: "https://yourapp.com/success",
            cancel_url: "https://yourapp.com/cancel",
              notify_url: "https://yourserver.com/payfast-webhook"
              }